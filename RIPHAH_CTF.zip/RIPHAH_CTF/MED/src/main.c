#include <stdio.h>

int main() {
	char buf[0x100];
	puts("Do you know about John Constantine?");
	gets(buf);
	puts("Not that john!");
}