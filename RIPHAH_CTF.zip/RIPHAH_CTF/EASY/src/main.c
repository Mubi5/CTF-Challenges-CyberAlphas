#include <stdio.h>

__attribute__((constructor))
void __constructor__(){
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void win(int a) {
    if(a == 0xc0ffee){
        system("/bin/sh\x00");
    }
    else {
        puts("Nope :(");
    }
}

int main() {
        char buf[0x100];
        printf("Are you enjoying the CyberAlphas CTF? ");
        gets(buf);
        puts("Me, too :)");
}
