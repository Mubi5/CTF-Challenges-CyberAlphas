<?php
$PDFLATEX = "/usr/bin/pdflatex";
$COMPILEDIR = __DIR__ . "/compile/";
$OUTPUTDIR = __DIR__ . "/pdf/";
$DLURL = "http://" . $_SERVER['SERVER_NAME'] . ":" . $_SERVER['SERVER_PORT'] . "/pdf/";
?>